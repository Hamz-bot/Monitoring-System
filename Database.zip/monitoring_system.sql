-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 01, 2025 at 09:06 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `monitoring_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `live_streams`
--

CREATE TABLE `live_streams` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `stream_key` varchar(255) NOT NULL,
  `status` enum('active','inactive') DEFAULT 'inactive',
  `started_at` datetime DEFAULT NULL,
  `ended_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `screenshots`
--

CREATE TABLE `screenshots` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `org` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `manager` varchar(100) NOT NULL,
  `date_registered` date NOT NULL,
  `app` varchar(50) NOT NULL,
  `activation` tinyint(1) NOT NULL,
  `tracking` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `org`, `email`, `password`, `manager`, `date_registered`, `app`, `activation`, `tracking`) VALUES
(1, 'Amna Usman', NULL, 'Floorland', 'amnausman@deedesigners.com', NULL, 'Umar Malik', '2025-07-09', 'Win(l): 2.0.9', 1, 1),
(2, 'Aoun Mahdi', NULL, 'Floorland', 'aounmahdi@deedesigners.com', NULL, 'Umar Malik', '2025-06-24', 'Win(l): 2.0.9', 1, 1),
(3, 'Aqib Malik', NULL, 'Lush Loom', 'aqibmalik@deedesigners.com', NULL, 'Umar Malik', '2025-04-28', 'Win(l): 2.0.9', 1, 1),
(4, 'Areeba Sajjad', NULL, 'Floorland', 'areebasajjad@deedesigners.com', NULL, 'Umar Malik', '2025-07-09', 'Win(l): 2.0.9', 1, 1),
(5, 'Asad Sohail', NULL, 'Evee.pk', 'asaadhail32@gmail.com', NULL, 'Umar Malik', '2025-09-05', 'Win(l): 2.0.9', 0, 0),
(6, 'Hira Sheikh', NULL, 'CreativeWorks', 'hirasheikh@deedesigners.com', NULL, 'Umar Malik', '2025-02-20', 'Win(l): 2.0.9', 1, 1),
(7, 'Hassan Khan ', NULL, 'Floorland', 'hassan4lodhi@gmail.com', NULL, 'Umar Malik', '2025-09-03', 'Mac(l): 2.0.9', 0, 0),
(8, 'Usman Malik', NULL, 'Cardibox_logistics', 'usman33_malik@gmail.com', NULL, 'Umar Malik', '2025-08-28', 'Win(l): 2.0.9', 0, 0),
(9, 'Arham sohail', NULL, 'Evee.pk', 'arhamsohail32@gmail.com', NULL, 'Umar Malik', '2025-09-05', 'Win(l): 2.0.9', 1, 1),
(160, 'Nyle Jaffary', NULL, 'Blanco', 'nylejaffary@gmail.com', NULL, 'Umar Malik', '2025-09-06', 'Mac(l): 2.0.9', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `live_streams`
--
ALTER TABLE `live_streams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `screenshots`
--
ALTER TABLE `screenshots`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `live_streams`
--
ALTER TABLE `live_streams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `screenshots`
--
ALTER TABLE `screenshots`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=164;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
